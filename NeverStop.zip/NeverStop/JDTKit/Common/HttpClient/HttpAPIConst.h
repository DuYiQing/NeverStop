//
//  HttpAPIConst.h
//  EAKit
//
//  Created by Eiwodetianna on 16/9/20.
//  Copyright © 2016年 Eiwodetianna. All rights reserved.
//

#ifndef HttpAPIConst_h
#define HttpAPIConst_h

static NSString *const kReleaseHostUrl = @"http://localhost";
static NSString *const kDevelopHostUrl = @"http://localhost";


static NSString *const kHomeReuqestPath = @"";


#endif /* HttpAPIConst_h */
