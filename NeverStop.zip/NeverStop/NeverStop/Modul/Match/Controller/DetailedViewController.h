//
//  DetailedViewController.h
//  NeverStop
//
//  Created by dllo on 16/10/24.
//  Copyright © 2016年 JDT. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Route;
@interface DetailedViewController : UIViewController

@property (nonatomic, strong) Route *roModel;
@end
