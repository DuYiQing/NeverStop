//
//  Detail.m
//  NeverStop
//
//  Created by dllo on 16/10/24.
//  Copyright © 2016年 JDT. All rights reserved.
//

#import "Detail.h"

@implementation Detail

@end
