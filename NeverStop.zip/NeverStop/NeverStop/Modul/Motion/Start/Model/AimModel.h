//
//  AimModel.h
//  NeverStop
//
//  Created by Jiang on 16/10/21.
//  Copyright © 2016年 JDT. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AimModel : NSObject
+ (NSArray *) creatAimData;
@end
